import json
# import numpy as np
# import os
# from tensorflow.keras.models import load_model

# Initialize the model
def init():
    # global model
    # model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'mnist.h5')
    # model = load_model(model_path)
    print('init')

# Run inference against data that is passed in
def run(raw_data):
    # data = np.array(json.loads(raw_data)['data'])
    # # make prediction
    # results = model.predict(data)
    # output = []
    # for result in results:
    #     output.append(construct_output(result))
    return 'output'

# Utility function to construct output data per item passed in
# def construct_output(result):
#     result_index = np.argmax(result)
#     result_value = result[result_index]
#     output = { 'value': str(result_index) }
#     output['certainty'] = result[result_index].item()
#     possibilities = {}
#     for i, val in enumerate(result): 
#         possibilities[i] = val.item() 
#     output['possibilities'] = possibilities    
#     return output
