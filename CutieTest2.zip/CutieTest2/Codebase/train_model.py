
import sys
import os
import tensorflow as tf
print(tf.__version__)
## Test GPU
device_name = tf.test.gpu_device_name()
if device_name != '/device:GPU:0':
  raise SystemError('GPU device not found')
print('Found GPU at: {}'.format(device_name))
print('')
config = tf.ConfigProto()
config.gpu_options.allow_growth = True

# import os
# cmd = 'nvcc -V'
# os.system(cmd)
from azureml.core import Run

os.environ["CUDA_VISIBLE_DEVICES"]="0,1,2,3"

#train the model with this import
from main_train_json_param import train

train()
run = Run.get_context()
run.upload_folder(name='model', path=os.path.abspath('./SROIE/final/'))


