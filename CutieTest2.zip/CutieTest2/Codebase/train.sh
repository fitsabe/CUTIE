python3.6 main_train_json.py --load_dict=True --doc_path=invoice_data --ckpt_path='./' --ckpt_file='../output/model/CUTIE.ckpt' --iterations=2 --log_save_step=1 --log_disp_step=1 --ckpt_save_step=1 --validation_step=1  --test_step=1  --log_path='../output/log'

source py36/bin/activate
python3.6 main_train_json.py --load_dict=True --doc_path=invoice_data --iterations=2 --log_save_step=1 --log_disp_step=1 --ckpt_save_step=1 --validation_step=1  --test_step=1  --log_path='../output/log'