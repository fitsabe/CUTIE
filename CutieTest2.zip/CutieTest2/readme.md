Install

sudo apt-get install cuda-drivers-fabricmanager-450

Install cuda driver

https://docs.nvidia.com/datacenter/tesla/tesla-installation-notes/index.html#ubuntu-lts

Env var setup

https://docs.nvidia.com/cuda/cuda-installation-guide-linux/index.html#post-installation-actions